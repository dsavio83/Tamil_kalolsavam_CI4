<style>
.display_none {
    display: none;
}
</style>

<?php
echo form_open('', array('id' => 'list_district'));
?>
<input type="hidden" name="sel_sub_district_id" id="sel_sub_district_id">
<!-- Back button -->
<div class="row mt-3 mb-3">
    <div class="col-12">
        <a href="<?php echo base_url('welcome/district_details'); ?>" class="btn btn-primary">
            <i class="bi bi-arrow-return-left"></i> Back
        </a>
    </div>
</div>
<div class="row mt-3">
    <div class="col-6 p-2"> <span style="font-weight: bold; font-size: 18px;">&nbsp;&nbsp;Clusters </span></div>
    <div class="col-6 p-2" style="text-align: right;"> <span style="font-weight: bold; font-size: 18px;">Print</span>&nbsp;&nbsp;
        <img src="<?php echo base_url('images/print_icon.png'); ?>" title="print" class="window_print" 
             onClick="javascript:printContent('print_content'); return false;" />
    </div>
</div>

 <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover" id="subDistrictTable">
                    <thead>
    <tr>
        <th width="5%" align="center">Sl No</th>
        <th width="20%" align="left">Sub-District Name</th>
        <th width="15%" align="center">Total Schools</th>
        <th width="15%" align="center">Data Entered</th>
        <th width="15%" align="center">Data Not Entered</th>
        <th width="15%" align="center">Confirmed</th>
        <th width="15%" align="center">Not Confirmed</th>
    </tr>
                    </thead>
                    <tbody>
    <?php
    $sub_district_details1 = $sub_district_details;
    if (is_array($sub_district_details) && count($sub_district_details) > 0) {
        foreach ($sub_district_details as $key => $sub_district_details) {
            $sub_details = $this->Login_Model->get_sub_school_details($sub_district_details['sub_district_code']);
            ?>
            <tr>
                <td align="center" class="table_row_first"><?php echo $key + 1 ?></td>
                <td  align="left" class="table_row_first">&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0)" onClick="javascript:fncListClustertDetails('<?php echo $sub_district_details['sub_district_code'] ?>');
                            return false;">
                           <?php echo $sub_district_details['sub_district_name']; ?>
                    </a>
                </td>
                <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] ?></td>
                <td  align="center" class="table_row_first"><?php echo $sub_details['data_entered'] ?></td>
                <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] - $sub_details['data_entered'] ?></td>
                <td  align="center" class="table_row_first"><?php echo $sub_details['confirmed'] ?></td>
                <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] - $sub_details['confirmed'] ?></td>
            </tr>

            <?php
        }
    }
    ?>
                    </tbody>
</table>
</div>
<!-- print content starts here----------------------------------->
<div id="print_content" class="display_none" >
    <table width="100%" border="1" cellspacing="0" cellpadding="6" align="center" class="table" style="margin-top:15px;">
        <tr>
            <th colspan="7"><?php echo $district_name; ?>&nbsp;District </th>
        </tr>
        <tr>
            <th width="5%" align="center">Sl No</th>
            <th width="20%" align="left">Sub-District Name</th>
            <th width="15%" align="center">Total Schools</th>
            <th width="15%" align="center">Data Entered</th>
            <th width="15%" align="center">Data Not Entered</th>
            <th width="15%" align="center">Confirmed</th>
            <th width="15%" align="center">Not Confirmed</th>
        </tr>
        <?php
        if (is_array($sub_district_details1) && count($sub_district_details1) > 0) {
            foreach ($sub_district_details1 as $key => $sub_district_details) {
                $sub_details = $this->Login_Model->get_sub_school_details($sub_district_details['sub_district_code']);
                ?>
                <tr>
                    <td align="center" class="table_row_first"><?php echo $key + 1 ?></td>
                    <td  align="left" class="table_row_first">&nbsp;&nbsp;&nbsp;
                        <?php echo $sub_district_details['sub_district_name']; ?>
                    </td>
                    <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] ?></td>
                    <td  align="center" class="table_row_first"><?php echo $sub_details['data_entered'] ?></td>
                    <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] - $sub_details['data_entered'] ?></td>
                    <td  align="center" class="table_row_first"><?php echo $sub_details['confirmed'] ?></td>
                    <td  align="center" class="table_row_first"><?php echo $sub_details['total_school'] - $sub_details['confirmed'] ?></td>
                </tr>

                <?php
            }
        }
        ?>

    </table>
</div>
<!-- display content ends here --------------------------------------->
<?php
echo form_close();
?>

<!-- DataTables initialization -->
<script>
    $(document).ready(function() {
        $('#subDistrictTable').DataTable({
            "pageLength": 10,
            "order": [[0, "asc"]]
        });
    });
</script>

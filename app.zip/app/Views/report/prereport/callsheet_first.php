<div class="pagetitle mb-3">
  <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
    <div>
      <h1 class="d-flex align-items-center gap-2 text-dark fw-bold mb-1">
        <i class="bi bi-file-earmark-spreadsheet-fill text-primary"></i>
        <span>அழைப்புத் தாள் அறிக்கைகள் (Call Sheet Reports)</span>
      </h1>
      <p class="text-muted small mb-0">நிகழ்வு வாரியாக, விழாவாரியாக மற்றும் மேடை/நாள் வாரியாக மேடை அழைப்புத் தாள்களை PDF ஆக பதிவிறக்குக.</p>
    </div>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-0 bg-light px-3 py-1.5 rounded-pill border">
        <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>welcome" class="text-decoration-none"><i class="bi bi-house-door-fill me-1"></i>முகப்பு</a></li>
        <li class="breadcrumb-item text-muted">மேடை அறிக்கைகள்</li>
        <li class="breadcrumb-item active text-primary fw-semibold" aria-current="page">அழைப்புத் தாள்</li>
      </ol>
    </nav>
  </div>
</div>

<!-- Navigation Pill Tabs for Stage Reports -->
<div class="card border-0 shadow-sm rounded-4 mb-4">
  <div class="card-body p-2">
    <div class="nav nav-pills nav-fill gap-2" id="reportTabs" role="tablist">
      <a class="nav-link active rounded-pill fw-semibold py-2 px-3 d-flex align-items-center justify-content-center gap-1.5" href="<?php echo base_url(); ?>report/prereport/callsheet_first">
        <i class="bi bi-person-lines-fill"></i>
        <span>அழைப்புத் தாள் (Call Sheet)</span>
      </a>
      <a class="nav-link rounded-pill text-secondary fw-semibold py-2 px-3 d-flex align-items-center justify-content-center gap-1.5" href="<?php echo base_url(); ?>report/prereport/timesheetinterface">
        <i class="bi bi-clock-history"></i>
        <span>நேரத் தாள் (Time Sheet)</span>
      </a>
      <a class="nav-link rounded-pill text-secondary fw-semibold py-2 px-3 d-flex align-items-center justify-content-center gap-1.5" href="<?php echo base_url(); ?>report/prereport/score_sheet_interfaces">
        <i class="bi bi-clipboard-check-fill"></i>
        <span>மதிப்பெண் தாள் (Score Sheet)</span>
      </a>
      <a class="nav-link rounded-pill text-secondary fw-semibold py-2 px-3 d-flex align-items-center justify-content-center gap-1.5" href="<?php echo base_url(); ?>report/prereport/tabulation_report_interface">
        <i class="bi bi-table"></i>
        <span>மதிப்பீட்டுத் தாள் (Tabulation)</span>
      </a>
      <a class="nav-link rounded-pill text-secondary fw-semibold py-2 px-3 d-flex align-items-center justify-content-center gap-1.5" href="<?php echo base_url(); ?>report/prereport/four_reports">
        <i class="bi bi-collection-fill"></i>
        <span>அனைத்தும் ஒன்றாக (All in One)</span>
      </a>
    </div>
  </div>
</div>

<!-- 3-Column Report Generation Row -->
<div class="row g-4 mb-4">

  <!-- Card 1: Call Sheet by Item -->
  <div class="col-12 col-xl-4">
    <?php echo form_open('report/prereportpdf/callsheet_report', array('id' => 'callsheet', 'target' => '_blank', 'class' => 'h-100')); ?>
    <input type="hidden" name="hidUserId" id="hidUserId" />

    <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden d-flex flex-column">
      <div class="card-header bg-gradient bg-primary text-white py-3 px-4 d-flex align-items-center gap-2">
        <i class="bi bi-journal-text fs-5"></i>
        <h6 class="mb-0 fw-bold">நிகழ்வு வாரியான அழைப்புத் தாள்</h6>
      </div>

      <div class="card-body p-4 flex-grow-1">
        <div class="mb-3">
          <label for="cmbFestType" class="form-label fw-bold text-dark small d-flex align-items-center gap-1">
            <i class="bi bi-trophy text-warning"></i>
            <span>விழா வகை <span class="text-danger">*</span></span>
          </label>
          <div class="input-group">
            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-tags-fill"></i></span>
            <?php echo form_dropdown("cmbFestType", $fest, '', 'class="form-select border-start-0 py-2" id="cmbFestType" onchange="javascript:fetch_callsheet_festival(this.value)" required'); ?>
          </div>
        </div>

        <div class="mb-4">
          <label for="cbo_item" class="form-label fw-bold text-dark small d-flex align-items-center gap-1">
            <i class="bi bi-card-list text-primary"></i>
            <span>நிகழ்வு / போட்டிப் பெயர் <span class="text-danger">*</span></span>
          </label>
          <div id="cmbitem">
            <?php echo form_dropdown("cbo_item", array('0' => '-- விழா தேர்வு செய்க --'), '', 'id="cbo_item" class="form-select py-2" required'); ?>
          </div>
          <small class="text-muted mt-1 d-block">விழாவைத் தேர்வு செய்தவுடன் நிகழ்வுகள் தோன்றும்.</small>
        </div>
      </div>

      <div class="card-footer bg-white border-top p-3 d-flex justify-content-center">
        <button type="submit" name="Report" value="Report" onclick="javascript: return callsheetfirst()" class="btn btn-primary px-4 py-2 rounded-pill shadow-sm fw-semibold d-inline-flex align-items-center gap-2 w-100 justify-content-center">
          <i class="bi bi-file-earmark-pdf-fill"></i>
          <span>PDF அறிக்கை காண்க</span>
        </button>
      </div>
    </div>
    <?php echo form_close(); ?>
  </div>



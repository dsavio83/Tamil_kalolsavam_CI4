  <!-- Card 3: Call Sheet by Date & Stage -->
  <div class="col-12 col-xl-4">
    <?php echo form_open('report/prereportpdf/call_date_stage', array('id' => 'clu', 'target' => '_blank', 'class' => 'h-100')); ?>
    <input type="hidden" name="hidUserId" id="hidUserId" />

    <div class="card border-0 shadow-sm rounded-4 h-100 overflow-hidden d-flex flex-column">
      <div class="card-header bg-gradient bg-primary text-white py-3 px-4 d-flex align-items-center gap-2">
        <i class="bi bi-calendar2-range-fill fs-5"></i>
        <h6 class="mb-0 fw-bold">நாள் & மேடை வாரியான அழைப்புத் தாள்</h6>
      </div>

      <div class="card-body p-4 flex-grow-1">
        <div class="mb-3">
          <label for="txtDate" class="form-label fw-bold text-dark small d-flex align-items-center gap-1">
            <i class="bi bi-calendar-event text-primary"></i>
            <span>தேதி (Date) <span class="text-danger">*</span></span>
          </label>
          <div class="input-group">
            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-calendar-check"></i></span>
            <?php echo form_dropdown("txtDate", @$date_array, (@$date != '') ? $date : '', 'class="form-select border-start-0 py-2" id="txtDate" required'); ?>
          </div>
        </div>

        <div class="mb-4">
          <label for="cmbstage" class="form-label fw-bold text-dark small d-flex align-items-center gap-1">
            <i class="bi bi-building text-primary"></i>
            <span>மேடை (Stage) <span class="text-danger">*</span></span>
          </label>
          <div class="input-group">
            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-geo-alt-fill text-danger"></i></span>
            <?php echo form_dropdown("cmbstage", $stage, '', 'class="form-select border-start-0 py-2" id="cmbstage" required'); ?>
          </div>
          <small class="text-muted mt-1 d-block">குறிப்பிட்ட மேடை மற்றும் தேதிக்கான நிகழ்வுகள் PDF ஆகத் தயாராகும்.</small>
        </div>
      </div>

      <div class="card-footer bg-white border-top p-3 d-flex justify-content-center">
        <button type="submit" name="Report" value="Report" class="btn btn-primary px-4 py-2 rounded-pill shadow-sm fw-semibold d-inline-flex align-items-center gap-2 w-100 justify-content-center">
          <i class="bi bi-file-earmark-pdf-fill"></i>
          <span>மேடை PDF அறிக்கை காண்க</span>
        </button>
      </div>
    </div>
    <?php echo form_close(); ?>
  </div>

</div>
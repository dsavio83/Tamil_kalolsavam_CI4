
<div align="center" class="heading_gray">
    <h3>Participant Wise : Rankwise  Result</h3>
</div>
<br />
<?php
echo form_open('report/afterresultreportpdf/datewisepart', array('id' => 'formDWP', 'target' => '_blank'));

?>
<form name="form1" method="post" action="">
    <table class="table">
        <tr>
            <th colspan="4" align="left">&nbsp;</th>
        </tr>
        <tr>
            <td width="10%" class="">&nbsp;</td>
            <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Festival Type : </td>
            <td align="left" width="55%" class="table_row_first">
                <?php echo form_dropdown("cmbFestType", $fest, '', 'class="form-control" id="cmbFestType" onchange="javascript:fetch_rankwise_participant_result(this.value)"'); ?>
            </td>
            <td width="18%">&nbsp;</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rank : </td>

            <td align="left" width="55%" class="table_row_first">
                <div id="cmbitem">
                    <?php echo form_dropdown("cbo_item", array('select'), 'class="form-control" id="cbo_item" '); ?>
                </div>
            </td>
            <td width="18%">&nbsp;</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
            <td align="left" width="55%" class="table_row_first">
                <label>
                    <input type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-primary" value="View Result">
                </label>       </td>
            <td width="18%">&nbsp;</td>
        </tr>

        <tr>
            <td align="center" colspan="4">&nbsp;</td>
        </tr>
    </table>
    <input type="hidden" name="hidUserId" id="hidUserId" />
</form>
<?php
//itemwise_report_interface
echo form_close();

?>

<div align="center" class="heading_gray">
    <h3>Item Wise Participants Result Details</h3>
</div>
<br />

<?php
echo form_open('district/report/resultindex/itemwise_report', array('id' => 'itemwise', 'target' => '_blank'));

?>
<table width="100%" border="0" cellspacing="0" cellpadding="4" align="center" class="heading_tab" style="margin-top:15px;">
    <tr>
        <th colspan="4" align="left">Select Item</th>
    </tr>
    <tr>
        <td width="10%" class="">&nbsp;</td>
        <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Festival Type : </td>
        <td align="left" width="55%" class="table_row_first"><?php echo form_dropdown("cmbFestType", $fest, '', 'class="form-control" id="cmbFestType" onchange="javascript:fetch_callsheet_festival(this.value)"'); ?></td>
        <td width="18%">&nbsp;</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Item Name : </td>

        <td align="left" width="55%" class="table_row_first"><div id="cmbitem"><?php echo form_dropdown("cbo_item", array('select'), '', 'class="form-control" id="cbo_item" '); ?></div></td>
        <td width="18%">&nbsp;</td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td align="left" width="27%" class="table_row_first">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
        <td align="left" width="55%" class="table_row_first">
                <label>
                    <input type="submit" name="btnSubmit" class="btn btn-primary" id="btnSubmit" value="View report" onClick="return checkitemwise();">
                </label>
        </td>
        <td width="18%">&nbsp;</td>
    </tr>

    <tr>
        <td align="center" colspan="4">&nbsp;</td>
    </tr>
</table>
<input type="hidden" name="hidUserId" id="hidUserId" />

<?php
//itemwise_report_interface

echo form_close();

?>

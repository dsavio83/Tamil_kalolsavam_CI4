<?php

namespace App\Controllers\User;


class User_Registration extends \App\Controllers\BaseController {

    function __construct () {
		parent::__construct ();
        $this->template->add_js('js/user/loginval.js');
        $this->load->model('user/User_Registration_Model');
        $this->load->model('General_Model');
        $this->load->model('Session_Model');
        $this->template->write_view('menu', 'menu', '');
        $this->template->write_view('left_panel', 'menu_left', '');
        $this->Session_Model->is_user_logged();
        $this->Session_Model->check_user_permission('1');
    }

    function index() {
        // Show sub-district admin users only (user_type = 3)
        $this->Content = array();
        $this->Content['user_rights'] = $this->User_Registration_Model->get_user_rights();
        $this->Content['retvalue'] = $this->User_Registration_Model->exist_user_details(3); // Sub-district admin users only
        $this->Content['user_type'] = 'admin'; // For view identification
        $this->template->write_view('content', 'user/user_registration', $this->Content);
        $this->template->load();
    }

    function cluster() {
        // Show cluster users only (user_type = 5)
        $this->Content['user_rights'] = $this->User_Registration_Model->get_user_rights();
        $this->Content['retvalue'] = $this->User_Registration_Model->exist_user_details(5); // Cluster users only
        $this->Content['user_type'] = 'cluster'; // For view identification
        $this->template->write_view('content', 'user/user_cluster_list', $this->Content);
        $this->template->load();
    }

    function add_user() {
        // Show add user form
        $this->Content['user_rights'] = $this->User_Registration_Model->get_user_rights();
        $this->Content['user_type'] = 'admin'; // For view identification
        $this->template->write_view('content', 'user/user_add_form', $this->Content);
        $this->template->load();
    }

    function add_cluster() {
        // Show add cluster form
        $this->Content['user_rights'] = $this->User_Registration_Model->get_user_rights();
        $this->Content['user_type'] = 'cluster'; // For view identification
        $this->template->write_view('content', 'user/user_cluster_add_form', $this->Content);
        $this->template->load();
    }

    function userinsert() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        if ($this->User_Registration_Model->check_username_exists('', $this->input->post('txtNewUserName'))) {
            $this->template->write('error', 'User name already exists');
            $this->index();
            return;
        }

        $this->User_Registration_Model->save_user_details();
        $this->template->write('message', 'User details saved successfully');
        $this->index();
    }

    function edit_user_detials() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $this->Content['selected_user'] = $this->User_Registration_Model->select_user_details();
        $this->Content['selected_user_rights'] = $this->User_Registration_Model->select_user_rights();
        $this->index();
    }

    function update_user_detials() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $userId = $this->input->post('hidUserId');
        if ($this->User_Registration_Model->check_username_exists($userId, $this->input->post('txtNewUserName'))) {
            $this->template->write('error', 'User name already exists');
            $this->index();
            return;
        }
        $this->User_Registration_Model->update_user_details();
        $this->template->write('message', 'User details updated successfully');
        $this->index();
    }

    function delete_user_detials() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $this->User_Registration_Model->delete_user_details();
        $this->template->write('message', 'User deleted successfully');
        $this->index();
    }

    // Cluster-specific methods
    function clusterinsert() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        if ($this->User_Registration_Model->check_username_exists('', $this->input->post('txtNewUserName'))) {
            $this->template->write('error', 'User name already exists');
            $this->cluster();
            return;
        }

        $this->User_Registration_Model->save_cluster_user_details();
        $this->template->write('message', 'Cluster user details saved successfully');
        $this->cluster();
    }

    function edit_cluster_details() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $this->Content['selected_user'] = $this->User_Registration_Model->select_user_details();
        $this->Content['selected_user_rights'] = $this->User_Registration_Model->select_user_rights();
        $this->cluster();
    }

    function update_cluster_details() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $userId = $this->input->post('hidUserId');
        if ($this->User_Registration_Model->check_username_exists($userId, $this->input->post('txtNewUserName'))) {
            $this->template->write('error', 'User name already exists');
            $this->cluster();
            return;
        }
        $this->User_Registration_Model->update_cluster_user_details();
        $this->template->write('message', 'Cluster user details updated successfully');
        $this->cluster();
    }

    function delete_cluster_details() {
        if (!($this->Session_Model->check_user_permission(1) || $this->Session_Model->check_user_permission(13))) {
            $this->template->write('error', permission_warning());
            $this->template->load();
            return;
        }
        $this->User_Registration_Model->delete_user_details();
        $this->template->write('message', 'Cluster user deleted successfully');
        $this->cluster();
    }

}

?>

<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use Config\ModelMap;
use App\Libraries\CiLoader;
use App\Libraries\Input;
use App\Libraries\FormValidation;
use App\Libraries\CiDatabase;

/**
 * Base Controller
 *
 * Compatibility layer mirroring the CI3 controller environment so that the
 * ported application controllers keep working: $this->db, $this->session,
 * $this->load, $this->input, $this->template, $this->form_validation,
 * $this->config, plus lazy model loading via $this->ModelName.
 *
 * All convenience properties are initialized in __construct() (like CI3) so
 * that ported controller constructors can use them immediately.
 */
class BaseController extends Controller
{
    /** @var \App\Libraries\CiDatabase */
    public $db;

    /** @var \App\Libraries\CiDatabase */
    public $db1;

    /** @var \CodeIgniter\Session\Session */
    public $session;

    /** @var \App\Libraries\CiLoader */
    public $load;

    /** @var \App\Libraries\Input */
    public $input;

    /** @var \App\Libraries\Template */
    public $template;

    /** @var object */
    public $config;

    /** @var \App\Libraries\FormValidation */
    public $form_validation;

    /** @var \CodeIgniter\HTTP\URI */
    public $uri;

    /** @var array models loaded by short name */
    protected $loaded_models = [];

    public function __construct()
    {
        // CI4's Controller has no __construct to chain to.
        $connection            = \Config\Database::connect();
        $this->db              = new CiDatabase($connection);
        $this->db1             = $this->db;
        $this->session         = session();
        $this->input           = new Input();
        $this->load            = new CiLoader($this);
        $this->config          = config(\Config\App::class);
        $this->form_validation = new FormValidation();
        $this->template        = service('template');
    }

    public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->uri = $request->getUri();
    }

    public function __get($name)
    {
        $lower = strtolower($name);

        if ($this->load instanceof CiLoader) {
            $m = $this->load->get_model($lower);
            if ($m !== null) {
                return $m;
            }
        }

        ModelMap::init();
        if (isset(ModelMap::$byName[$lower])) {
            if (isset($this->loaded_models[$lower])) {
                return $this->loaded_models[$lower];
            }
            $fqcn = ModelMap::$byName[$lower];
            $instance = new $fqcn();
            $this->loaded_models[$lower] = $instance;
            $this->{$name} = $instance;
            return $instance;
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property: ' . static::class . '::$' . $name .
            ' in ' . ($trace[0]['file'] ?? '') . ' on line ' . ($trace[0]['line'] ?? '') .
            ' (use $this->load->model() to load it)',
            E_USER_NOTICE
        );
        return null;
    }
}

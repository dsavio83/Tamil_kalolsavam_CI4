<?php

namespace App\Controllers;


class Welcome extends \App\Controllers\BaseController {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	function __construct () {
		parent::__construct ();
		$this->Session_Model->is_user_logged(true);
        $this->template->add_js('js/admin/admin.js');
        $this->template->write_view('menu', 'menu', '');
        $this->template->write_view('left_panel', 'menu_left', '');
        $this->load->model('login/Login_Model');
        $this->Contents = array();
	}
	public function index()
	{
		// Check if school_details entry exists for school user
		$school_code = $this->session->get('SCHOOL_CODE');
		if (!$school_code && (int)$this->session->get('USER_TYPE') == 5) {
			$db = \Config\Database::connect();
			$cluster = $db->table('user_cluster')->select('school_code')->where('user_id', $this->session->get('USERID'))->get()->getRowArray();
			if (!empty($cluster['school_code'])) {
				$school_code = $cluster['school_code'];
				$this->session->set('SCHOOL_CODE', $school_code);
			}
		}
		if ($school_code && $school_code != 0 && (int)$this->session->get('USER_TYPE') == 5) {
			$db = \Config\Database::connect();
			$builder = $db->table('school_details');
			$builder->where('school_code', $school_code);
			if ($builder->countAllResults() == 0) {
				session()->setFlashdata('message', 'Please fill out your school profile details first.');
				redirect('schools/profile');
				return;
			}
		}

		// $this->load->view('welcome_message');

		        //echo $this->session->get('USER_TYPE');.
				if ($this->session->get('USER_TYPE') == 0 || $this->session->get('USER_TYPE') == 1) {
					redirect('welcome/district_details');
				}
				if ($this->session->get('USER_TYPE') == 5) {
					redirect('welcome/cluster_schools');
				}
				if ($this->session->get('USER_TYPE') == 2) {
					//redirect('welcome/sub_district_details');
				}
				if ($this->session->get('USER_TYPE') == 3) {
					//redirect('welcome/cluster_details');
				}
				$welcome_label = '';
				$fest_name = '';
				$venue = '';
				$start_date = '';
				$end_date = '';
				$current_year = date('Y');
                $next_year = $current_year + 1;
                $sub_dist_code = $this->session->get('SUB_DISTRICT');

                if ($this->session->get('USER_TYPE') == 3) {
                    $sub_dist_name = get_sub_dist_name($sub_dist_code);
                    $welcome_label = $sub_dist_name . " District Tamil Kalaivizha $current_year - $next_year";
                } else if ($this->session->get('USER_TYPE') == 2) {
                    $dist_code = $this->session->get('DISTRICT');
                    $dist_name = get_dist_name($this->session->get('DISTRICT'));
                    $welcome_label = $dist_name . " District Tamil Kalaivizha $current_year - $next_year";
                } else if ($this->session->get('USER_TYPE') < 2) {
                    $dist_code = $this->session->get('DISTRICT');
                    $dist_name = get_dist_name($this->session->get('DISTRICT'));
                    $welcome_label = "Tamil Kalaivizha $current_year - $next_year";
                }
                
                // Get sub-district kalolsavam details and statistics
                $this->Contents['statistics'] = $this->get_statistics($sub_dist_code);
                if ($sub_dist_code) {
                    $kalolsavam_details = $this->db->select('sub_dist_kalolsavam_name, venue, start_date, end_date')
                        ->from('sub_dist_kalolsavam_master')
                        ->where('sub_district_code', $sub_dist_code)
                        ->get()->getRowArray();
                    
                    if ($kalolsavam_details) {
                        $fest_name = $kalolsavam_details['sub_dist_kalolsavam_name'];
                        $venue = $kalolsavam_details['venue'];
                        $start_date = $kalolsavam_details['start_date'];
                        $end_date = $kalolsavam_details['end_date'];
                    }
                }

               $this->Contents['has_kalolsavam'] = !empty($kalolsavam_details);

                // Fetch stage schedule for the dashboard
                $schedule = $this->db->query("
                    SELECT sm.stage_id, sm.stage_name, im.item_name, sim.start_time, sim.item_time, im.gender, im.item_code
                    FROM stage_item_master sim
                    INNER JOIN stage_master sm ON sim.stage_id = sm.stage_id
                    INNER JOIN item_master im ON sim.item_code = im.item_code
                    ORDER BY sm.stage_name ASC, sim.start_time ASC
                ")->getResultArray();
                
                $stages = array();
                foreach ($schedule as $row) {
                    $stage_id = $row['stage_id'];
                    if (!isset($stages[$stage_id])) {
                        $stages[$stage_id] = array(
                            'name' => $row['stage_name'],
                            'events' => array()
                        );
                    }
                    $stages[$stage_id]['events'][] = $row;
                }
                $this->Contents['stages_schedule'] = $stages;

				$this->Contents['welcome_label'] = $welcome_label;
				$this->Contents['fest_name'] = $fest_name;
				$this->Contents['venue'] = $venue;
				$this->Contents['start_date'] = $start_date;
				$this->Contents['end_date'] = $end_date;
				$this->template->write_view('content', 'welcome', $this->Contents);
				$this->template->load();
	}


    /* unction for list the user cluster details */

    function cluster_details($message = '') {

        if ($message) {
            if (is_array($message['error_array'])) {
                foreach ($message['error_array'] as $error) {
                    $this->template->write('error', $error . '<br>');
                }
            }
        }
        if ('' != trim($this->input->get_post('sel_sub_district_id')))
            $subdist = $this->input->get_post('sel_sub_district_id');
        else
            $subdist = $this->session->get('SUB_DISTRICT');

        $this->Contents = array();
        $this->template->write('title', '');
        $sub_admin = $this->Login_Model->get_sub_admin_details($subdist);
        $clusters = $this->Login_Model->get_cluster_details($subdist);
        $this->Contents['sub_admin'] = $sub_admin;
        $this->Contents['clusters'] = $clusters;

        $this->Contents['district_code'] = $this->Login_Model->get_subdist_district_code($subdist);

        $sub_school = $this->Login_Model->get_sub_school_details($subdist);
        $nonclust = $this->Login_Model->get_unclustersch_details($subdist);

        $val = $this->Login_Model->get_unclustersch_finentry($subdist);
        $this->Contents['sub_school'] = $sub_school;
        $this->Contents['nonclust'] = $nonclust;
        $this->Contents['val'] = $val;
        $this->Contents['subdst'] = $subdist;

        $this->template->write_view('content', 'login/clusters', $this->Contents);
        $this->template->load();
    }

    function cluster_schools() {
        $this->Contents = array();
        $this->template->write('title', '');
        if ($this->input->post('hidClusterId')) {
            $clusterId = $this->input->post('hidClusterId');
        } else {
            $clusterId = '';
        }
        $cluster = $this->Login_Model->clusterdetails($clusterId);
        $school = $this->Login_Model->schooldetails($clusterId);
        $particip = $this->Login_Model->schoolpartcip();
        $this->Contents['cluster'] = $cluster;
        $this->Contents['school'] = $school;
        $this->Contents['part'] = $particip;
        
        if (count($school) > 0) {
            $school_code = $school[0]['school_code'];
            $sub_district_code = $school[0]['sub_district_code'];
            
            $this->Contents['statistics'] = $this->get_school_stats($school_code);
            $this->Contents['venue_details'] = $this->get_venue($sub_district_code);
            $this->Contents['sub_district_name'] = $this->get_subdist_name($sub_district_code);
            $this->Contents['district_code'] = $this->Login_Model->get_subdist_district_code($sub_district_code);
            $this->Contents['sub_district_code'] = $sub_district_code;
            $this->Contents['cluster_id'] = $clusterId;
            
            $this->template->write_view('content', 'login/clustschool', $this->Contents);
            $this->template->load();
        }
    }
    
    private function get_school_stats($school_code) {
        $stats = array('total_students' => 0, 'boys_count' => 0, 'girls_count' => 0,
            'lp_total' => 0, 'lp_boys' => 0, 'lp_girls' => 0,
            'up_total' => 0, 'up_boys' => 0, 'up_girls' => 0,
            'hs_total' => 0, 'hs_boys' => 0, 'hs_girls' => 0,
            'hss_total' => 0, 'hss_boys' => 0, 'hss_girls' => 0,
            'result_percentage' => 0, 'total_items_participated' => 0, 'prizes_won' => 0, 'class_wise' => array());
        
        $result = $this->db->query("SELECT gender, COUNT(*) as count FROM participant_details WHERE school_code = ? GROUP BY gender", array($school_code));
        if ($result) {
            foreach ($result->getResultArray() as $row) {
                $stats['total_students'] += (int)$row['count'];
                if ($row['gender'] == 'B') $stats['boys_count'] = (int)$row['count'];
                if ($row['gender'] == 'G') $stats['girls_count'] = (int)$row['count'];
            }
        }
        
        $result = $this->db->query("SELECT class, gender, COUNT(*) as count FROM participant_details WHERE school_code = ? GROUP BY class, gender", array($school_code));
        if ($result) {
            foreach ($result->getResultArray() as $row) {
                $class = trim($row['class']);
                if (!isset($stats['class_wise'][$class])) $stats['class_wise'][$class] = array('boys' => 0, 'girls' => 0, 'total' => 0);
                $count = (int)$row['count'];
                $stats['class_wise'][$class]['total'] += $count;
                if ($row['gender'] == 'B') $stats['class_wise'][$class]['boys'] = $count;
                if ($row['gender'] == 'G') $stats['class_wise'][$class]['girls'] = $count;
                
                if (is_numeric($class)) {
                    $c = (int)$class;
                    if ($c >= 1 && $c <= 4) {
                        $stats['lp_total'] += $count;
                        if ($row['gender'] == 'B') $stats['lp_boys'] += $count;
                        if ($row['gender'] == 'G') $stats['lp_girls'] += $count;
                    } elseif ($c >= 5 && $c <= 7) {
                        $stats['up_total'] += $count;
                        if ($row['gender'] == 'B') $stats['up_boys'] += $count;
                        if ($row['gender'] == 'G') $stats['up_girls'] += $count;
                    } elseif ($c >= 8 && $c <= 10) {
                        $stats['hs_total'] += $count;
                        if ($row['gender'] == 'B') $stats['hs_boys'] += $count;
                        if ($row['gender'] == 'G') $stats['hs_girls'] += $count;
                    } elseif ($c >= 11 && $c <= 12) {
                        $stats['hss_total'] += $count;
                        if ($row['gender'] == 'B') $stats['hss_boys'] += $count;
                        if ($row['gender'] == 'G') $stats['hss_girls'] += $count;
                    }
                }
            }
        }
        
        $result = $this->db->query("SELECT COUNT(DISTINCT item_code) as count FROM participant_item_details WHERE school_code = ?", array($school_code));
        if ($result && $result->getNumRows() > 0) $stats['total_items_participated'] = (int)$result->getRowArray()['count'];
        
        $result = $this->db->query("SELECT COUNT(*) as count FROM result_master WHERE school_code = ? AND grade IN ('A', 'B', 'C')", array($school_code));
        if ($result && $result->getNumRows() > 0) $stats['prizes_won'] = (int)$result->getRowArray()['count'];
        
        if ($stats['total_items_participated'] > 0) $stats['result_percentage'] = round(($stats['prizes_won'] / $stats['total_items_participated']) * 100, 2);
        
        return $stats;
    }
    
    private function get_venue($sub_district_code) {
        $result = $this->db->query("SELECT venue, start_date, end_date FROM sub_dist_kalolsavam_master WHERE sub_district_code = ?", array($sub_district_code));
        return ($result && $result->getNumRows() > 0) ? $result->getRowArray() : array('venue' => '', 'start_date' => '', 'end_date' => '');
    }
    
    private function get_subdist_name($sub_district_code) {
        $result = $this->db->query("SELECT sub_district_name FROM sub_district_master WHERE sub_district_code = ?", array($sub_district_code));
        return ($result && $result->getNumRows() > 0) ? $result->getRowArray()['sub_district_name'] : '';
    }

    function pdf_report() {
        $this->load->library('html2pdf');
        $this->Contents = array();

        $content = get_encr_password('password');
        $html2pdf = new HTML2PDF('P', 'A4', 'en');
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->WriteHTML($content, '');
        $html2pdf->Output('project_urls.pdf', 'I');
    }

    function confirm_sub_dist_schools() {
        $this->load->model('user/User_Cluster_Model');
        $message = '';
        if ($this->session->get('USER_TYPE') == 3) {
            $message = $this->User_Cluster_Model->confirm_sub_dist_schools();
        }
        $this->cluster_details($message);
    }

    function district_details() {
        if ($this->session->get('USER_TYPE') == 0 || $this->session->get('USER_TYPE') == 1) {
            $this->Contents['district_details'] = $this->General_Model->get_data('rev_district_master', '*', array(), 'rev_district_code');

			//	var_dump( $this->Contents['district_details']); 
			//	die;
            //$this->Contents['dist_school']		=	$this->Login_Model->get_district_school_details();
            //var_dump($this->Contents['dist_school']);exit();
            $this->template->write_view('content', 'login/list_district_details', $this->Contents);
        } else
            redirect('welcome');
        $this->template->load();
    }

    function sub_district_details() {
        if ($this->session->get('USER_TYPE') == 0 || $this->session->get('USER_TYPE') == 1 || $this->session->get('USER_TYPE') == 2) {
            if ($this->input->get_post('sel_district_id'))
                $district_id = $this->input->get_post('sel_district_id');
            else if ($this->session->get('DISTRICT'))
                $district_id = $this->session->get('DISTRICT');
            else
                redirect('welcome');

            $district_details = $this->General_Model->get_data('rev_district_master', '*', array("rev_district_code" => $district_id), 'rev_district_code');
            $this->Contents['district_name'] = $district_details[0]['rev_district_name'];
            $this->Contents['district_code'] = $district_id;
            $this->Contents['sub_district_details'] = $this->General_Model->get_data('sub_district_master', '*', array("rev_district_code" => $district_id), 'sub_district_name');
            $this->template->write_view('content', 'login/list_sub_district_details', $this->Contents);
        } else
            redirect('welcome');
        $this->template->load();
    }

    function nonclustdetails() {
        $subdist = $this->input->post('hidClusterId');
        $this->Contents = array();
        $this->template->write('title', '');
        $val = $this->Login_Model->nonclustdetails_sname($subdist);
        $nonschool = $this->Login_Model->nonclustdetails_nosname($subdist);
        $this->Contents['val'] = $val;
        $this->Contents['nonschool'] = $nonschool;
        $this->Contents['sub_district_code'] = $subdist;
        $this->Contents['district_code'] = $this->Login_Model->get_subdist_district_code($subdist);
        $this->template->write_view('content', 'login/nonclustschool', $this->Contents);
        $this->template->load();
    }

    function changeKalolsavam() {
        $subdist = $this->session->get('SUB_DISTRICT');
        $sub_dist_name = get_sub_dist_name($this->session->get('SUB_DISTRICT'));
        if ($change = $this->Login_Model->changeKalolsavam($subdist, $sub_dist_name)) {
            $this->template->write('message', $sub_dist_name . 'Kalolsavam Name changed sucess fully<br>');
        } else
            $this->template->write('error', 'Cant Change kalolsavam Name : <br>');

        $this->template->load();
    }

    function export_photo() {
        $this->load->library('zip');
        $this->load->helper('file');
        ini_set('memory_limit', '2048M');
        $photo_path = 'photos/' . $this->session->get('SUB_DISTRICT') . '/';
        $this->zip->read_dir($photo_path);
        $this->zip->download('photos_' . $this->session->get('SUB_DISTRICT') . '.zip');
    }

    function itemMaster() {
        $query1 = mysqli_query('INSERT INTO `item_master` (`item_id`, `item_code`, `vibhagam_id`, `fest_id`, `item_name`, `gender`, `item_type`, `max_time`, `time_type`, `max_participants`, `max_pinnani`, `is_off_stage`) VALUES
(305, 998, 21, 4, "Keralanadanam (Girls)", "G", "S", 15, "M", 1, 0, "N")');
        $query2 = mysqli_query("INSERT INTO `item_master` (`item_id`, `item_code`, `vibhagam_id`, `fest_id`, `item_name`, `gender`, `item_type`, `max_time`, `time_type`, `max_participants`, `max_pinnani`, `is_off_stage`) VALUES
(304, 682, 10, 3, 'Kerala Nadanam (Girls)', 'G', 'S', 15, 'M', 1, 0, 'N')");
    }

    private function get_statistics($sub_dist_code) {
        $stats = array(
            'total_schools' => 0, 'finalized_schools' => 0,
            'lp_schools' => 0, 'lp_boys' => 0, 'lp_girls' => 0, 'lp_total' => 0, 'lp_finalized' => 0,
            'up_schools' => 0, 'up_boys' => 0, 'up_girls' => 0, 'up_total' => 0, 'up_finalized' => 0,
            'hs_schools' => 0, 'hs_boys' => 0, 'hs_girls' => 0, 'hs_total' => 0, 'hs_finalized' => 0,
            'hss_schools' => 0, 'hss_boys' => 0, 'hss_girls' => 0, 'hss_total' => 0, 'hss_finalized' => 0,
            'total_participants' => 0, 'boys_count' => 0, 'girls_count' => 0,
            'total_items' => 0, 'completed_items' => 0
        );
        
        if (!$sub_dist_code) return $stats;
        
        $school_query = "SELECT sm.school_code, sm.school_name, sd.class_start, sd.class_end, sd.is_finalize
        FROM school_master sm
        LEFT JOIN school_details sd ON sm.school_code = sd.school_code
        WHERE sm.sub_district_code = ? AND sm.school_status = 'A'";
        
        $schools = $this->db->query($school_query, array($sub_dist_code))->getResultArray();
        $stats['total_schools'] = count($schools);
        
        $lp_schools = array();
        $up_schools = array();
        $hs_schools = array();
        $hss_schools = array();
        
        foreach ($schools as $school) {
            $start = $school['class_start'] !== null ? (int)$school['class_start'] : null;
            $end = $school['class_end'] !== null ? (int)$school['class_end'] : null;
            $finalized = $school['is_finalize'] == 'Y';
            
            if ($finalized) $stats['finalized_schools']++;
            
            $has_lp = false;
            $has_up = false;
            $has_hs = false;
            $has_hss = false;
            
            if ($start !== null && $end !== null) {
                $has_lp = ($start <= 4 && $end >= 1);
                $has_up = ($start <= 7 && $end >= 5);
                $has_hs = ($start <= 10 && $end >= 8);
                $has_hss = ($start <= 12 && $end >= 11);
            } else {
                // Guess category based on school name
                $name = strtoupper($school['school_name']);
                if (strpos($name, 'L.P.') !== false || strpos($name, 'L P') !== false || strpos($name, 'LPS') !== false || strpos($name, 'LP S') !== false || strpos($name, 'PRIMARY') !== false) {
                    $has_lp = true;
                }
                if (strpos($name, 'U.P.') !== false || strpos($name, 'U P') !== false || strpos($name, 'UPS') !== false || strpos($name, 'UP S') !== false) {
                    $has_up = true;
                }
                if (strpos($name, 'H.S.') !== false || strpos($name, 'H S') !== false || strpos($name, 'HIGH SCHOOL') !== false || strpos($name, 'H.S.S') !== false || strpos($name, 'HSS') !== false || strpos($name, 'VHSS') !== false || strpos($name, 'V.H.S.S') !== false) {
                    $has_hs = true;
                }
                if (strpos($name, 'H.S.S') !== false || strpos($name, 'HSS') !== false || strpos($name, 'VHSS') !== false || strpos($name, 'V.H.S.S') !== false) {
                    $has_hss = true;
                }
            }
            
            if ($has_lp) {
                $stats['lp_schools']++;
                $lp_schools[] = $school['school_code'];
                if ($finalized) $stats['lp_finalized']++;
            }
            if ($has_up) {
                $stats['up_schools']++;
                $up_schools[] = $school['school_code'];
                if ($finalized) $stats['up_finalized']++;
            }
            if ($has_hs) {
                $stats['hs_schools']++;
                $hs_schools[] = $school['school_code'];
                if ($finalized) $stats['hs_finalized']++;
            }
            if ($has_hss) {
                $stats['hss_schools']++;
                $hss_schools[] = $school['school_code'];
                if ($finalized) $stats['hss_finalized']++;
            }
        }
        
        $participant_query = "SELECT pd.gender, COUNT(*) as count
        FROM participant_details pd
        INNER JOIN school_master sm ON pd.school_code = sm.school_code
        WHERE sm.sub_district_code = ?
        GROUP BY pd.gender";
        
        $total_participants = $this->db->query($participant_query, array($sub_dist_code))->getResultArray();
        
        foreach ($total_participants as $p) {
            $count = (int)$p['count'];
            $stats['total_participants'] += $count;
            if ($p['gender'] == 'B') $stats['boys_count'] += $count;
            if ($p['gender'] == 'G') $stats['girls_count'] += $count;
        }
        
        $category_query = "SELECT pd.class, pd.gender, COUNT(*) as count
        FROM participant_details pd
        INNER JOIN school_master sm ON pd.school_code = sm.school_code
        WHERE sm.sub_district_code = ?
        GROUP BY pd.class, pd.gender";
        
        $participants = $this->db->query($category_query, array($sub_dist_code))->getResultArray();
        
        foreach ($participants as $p) {
            $class_val = trim($p['class']);
            $gender = $p['gender'];
            $count = (int)$p['count'];
            
            if (is_numeric($class_val)) {
                $class = (int)$class_val;
                
                if ($class >= 1 && $class <= 4) {
                    $stats['lp_total'] += $count;
                    if ($gender == 'B') $stats['lp_boys'] += $count;
                    if ($gender == 'G') $stats['lp_girls'] += $count;
                } elseif ($class >= 5 && $class <= 7) {
                    $stats['up_total'] += $count;
                    if ($gender == 'B') $stats['up_boys'] += $count;
                    if ($gender == 'G') $stats['up_girls'] += $count;
                } elseif ($class >= 8 && $class <= 10) {
                    $stats['hs_total'] += $count;
                    if ($gender == 'B') $stats['hs_boys'] += $count;
                    if ($gender == 'G') $stats['hs_girls'] += $count;
                } elseif ($class >= 11 && $class <= 12) {
                    $stats['hss_total'] += $count;
                    if ($gender == 'B') $stats['hss_boys'] += $count;
                    if ($gender == 'G') $stats['hss_girls'] += $count;
                }
            }
        }
        
        $item_query = "SELECT COUNT(DISTINCT im.item_code) as total_items,
            COUNT(DISTINCT CASE WHEN rm.is_finish = 'Y' THEN rm.item_code END) as completed_items
        FROM item_master im
        LEFT JOIN result_master rm ON im.item_code = rm.item_code";
        $item_result = $this->db->query($item_query);
        if ($item_result) {
            $item_stats = $item_result->getRowArray();
            $stats['total_items'] = (int)$item_stats['total_items'];
            $stats['completed_items'] = (int)$item_stats['completed_items'];
        }
        
        return $stats;
    }
}

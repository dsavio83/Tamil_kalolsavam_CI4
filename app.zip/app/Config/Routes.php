<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Login::index');
$routes->match(['get', 'post'], 'welcome', 'Welcome::index');

$routes->match(['get', 'post'], 'login', 'Login::index');
$routes->post('login/ajax_login', 'Login::ajax_login');
$routes->match(['get', 'post'], 'login/logout', 'Login::logout');

// Public Result View Endpoints (No Login Required)
$routes->match(['get', 'post'], 'publishresult/publicresult/resultview', 'Publishresult\Publicresult::resultview');
$routes->match(['get', 'post'], 'publishresult/publicresult', 'Publishresult\Publicresult::resultview');
$routes->match(['get', 'post'], 'publishresult/publicresult/get_item_results_ajax', 'Publishresult\Publicresult::get_item_results_ajax');
$routes->match(['get', 'post'], 'publishresult/publicresult/result_declared', 'Publishresult\Publicresult::result_declared');
$routes->match(['get', 'post'], 'publishresult/publicresult/get_results_by_item', 'Publishresult\Publicresult::get_results_by_item');
$routes->match(['get', 'post'], 'publishresult/publicresult/schoolpoints', 'Publishresult\Publicresult::schoolpoints');
$routes->match(['get', 'post'], 'publishresult/publicresult/subdistrictpoints', 'Publishresult\Publicresult::subdistrictpoints');
$routes->match(['get', 'post'], 'publishresult/publicresult/allresults', 'Publishresult\Publicresult::allresults');
$routes->match(['get', 'post'], 'publishresult/publicresult/allfestschools', 'Publishresult\Publicresult::allfestschools');
$routes->match(['get', 'post'], 'publishresult/publicresult/festval_status', 'Publishresult\Publicresult::festval_status');
$routes->match(['get', 'post'], 'publishresult/publicresult/festival_allitem', 'Publishresult\Publicresult::festival_allitem');
$routes->match(['get', 'post'], 'publishresult/publicresult/finished_item', 'Publishresult\Publicresult::finished_item');
$routes->match(['get', 'post'], 'publishresult/publicresult/incomplete_item', 'Publishresult\Publicresult::incomplete_item');

// Confirmed PDF Endpoints
$routes->match(['get', 'post'], 'itemreport/itemreport_pdf', 'Itemreport::itemreport_pdf');
$routes->match(['get', 'post'], 'report/masterreport/item_code_pdf', 'Report\Masterreport::item_code_pdf');
$routes->match(['get', 'post'], 'report/prereportpdf/participant_regno_photo', 'Report\Prereportpdf::participant_regno_photo');

// ------------------------------------------------------------------
// PHASE 75 - PRIMARY BUSINESS WORKFLOW ROUTES (OPTION A: explicit GET)
// Restores reachability of the minimum primary post-login destinations.
// All target controllers self-protect via is_user_logged()/permission
// checks in their constructors. Dangerous/legacy endpoints (Test,
// Import restore/initialize, Export, Afterresult_model, staticreport,
// certificate calibration, and the broad report surface) are NOT routed.
// ------------------------------------------------------------------

// Post-login redirect targets
$routes->get('welcome/district_details', 'Welcome::district_details');
$routes->match(['get', 'post'], 'welcome/sub_district_details', 'Welcome::sub_district_details');
$routes->match(['get', 'post'], 'welcome/cluster_details', 'Welcome::cluster_details');
$routes->match(['get', 'post'], 'welcome/cluster_schools', 'Welcome::cluster_schools');
$routes->post('welcome/nonclustdetails', 'Welcome::nonclustdetails');
$routes->get('login/change_password', 'Login::change_password');
$routes->post('login/change_Pwd_insert', 'Login::change_Pwd_insert');

// Settings / Kalolsavam definition & APIs
$routes->match(['GET', 'POST'], 'admin/kalolsavam', 'Admin\Kalolsavam::index');
$routes->match(['GET', 'POST'], 'admin/kalolsavam/add_kalolsavam', 'Admin\Kalolsavam::add_kalolsavam');
$routes->match(['GET', 'POST'], 'admin/kalolsavam/edit_kalolsavam', 'Admin\Kalolsavam::edit_kalolsavam');
$routes->match(['GET', 'POST'], 'admin/kalolsavam/update_kalolsavam', 'Admin\Kalolsavam::update_kalolsavam');
$routes->match(['GET', 'POST'], 'admin/kalolsavam/get_kalolsavam_ajax', 'Admin\Kalolsavam::get_kalolsavam_ajax');
$routes->match(['GET', 'POST'], 'admin/kalolsavam/save_kalolsavam_ajax', 'Admin\Kalolsavam::save_kalolsavam_ajax');

// School Profile
$routes->match(['GET', 'POST'], 'schools/profile', 'Schools\Registration::profile');
$routes->match(['GET', 'POST'], 'schools/profile/edit', 'Schools\Registration::edit_school_profile');
$routes->match(['GET', 'POST'], 'schools/profile/update', 'Schools\Registration::update_profile');

// School Registration CRUD & AJAX endpoints
$routes->match(['GET', 'POST'], 'schools/registration', 'Schools\Registration::index');
$routes->match(['GET', 'POST'], 'schools/registration/save_participant', 'Schools\Registration::save_participant');
$routes->match(['GET', 'POST'], 'schools/registration/edit_participant_details', 'Schools\Registration::edit_participant_details');
$routes->match(['GET', 'POST'], 'schools/registration/update_participant_details', 'Schools\Registration::update_participant_details');
$routes->match(['GET', 'POST'], 'schools/registration/delete_participant_details', 'Schools\Registration::delete_participant_details');
$routes->match(['GET', 'POST'], 'schools/registration/get_participant_data', 'Schools\Registration::get_participant_data');
$routes->match(['GET', 'POST'], 'schools/registration/get_school_details', 'Schools\Registration::get_school_details');
$routes->match(['GET', 'POST'], 'schools/registration/get_school_list', 'Schools\Registration::get_school_list');
$routes->match(['GET', 'POST'], 'schools/registration/get_school_data', 'Schools\Registration::get_school_data');
$routes->match(['GET', 'POST'], 'schools/registration/get_items_by_class', 'Schools\Registration::get_items_by_class');
$routes->match(['GET', 'POST'], 'schools/registration/get_item_details', 'Schools\Registration::get_item_details');
$routes->match(['GET', 'POST'], 'schools/registration/edit_school_details', 'Schools\Registration::edit_school_details');
$routes->match(['GET', 'POST'], 'schools/registration/update', 'Schools\Registration::update');
$routes->match(['GET', 'POST'], 'schools/registration/finalize_data', 'Schools\Registration::finalize_data');
$routes->match(['GET', 'POST'], 'schools/registration/update_group_captain', 'Schools\Registration::update_group_captain');

// Admin School Entry CRUD & AJAX endpoints
$routes->match(['GET', 'POST'], 'schools/school_entry', 'Schools\Registration::school_entry');
$routes->match(['GET', 'POST'], 'schools/school_entry/save_participant', 'Schools\Registration::save_participant');
$routes->match(['GET', 'POST'], 'schools/school_entry/edit_participant_details', 'Schools\Registration::edit_participant_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/update_participant_details', 'Schools\Registration::update_participant_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/delete_participant_details', 'Schools\Registration::delete_participant_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_participant_data', 'Schools\Registration::get_participant_data');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_school_details', 'Schools\Registration::get_school_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_school_list', 'Schools\Registration::get_school_list');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_school_data', 'Schools\Registration::get_school_data');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_items_by_class', 'Schools\Registration::get_items_by_class');
$routes->match(['GET', 'POST'], 'schools/school_entry/get_item_details', 'Schools\Registration::get_item_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/edit_school_details', 'Schools\Registration::edit_school_details');
$routes->match(['GET', 'POST'], 'schools/school_entry/update', 'Schools\Registration::update');
$routes->match(['GET', 'POST'], 'schools/school_entry/finalize_data', 'Schools\Registration::finalize_data');
$routes->match(['GET', 'POST'], 'schools/school_entry/update_group_captain', 'Schools\Registration::update_group_captain');

$routes->match(['GET', 'POST'], 'schools/registration_report', 'Schools\Registration_Report::index');
$routes->match(['GET', 'POST'], 'schools/registration_report/pdf_report', 'Schools\Registration_Report::pdf_report');
$routes->match(['GET', 'POST'], 'schools/registration_report/html_report', 'Schools\Registration_Report::html_report');
$routes->match(['get', 'post'], 'schools/school_master', 'Schools\School_Master::index');
$routes->post('schools/school_master/add_school_details', 'Schools\School_Master::add_school_details');
$routes->match(['get', 'post'], 'schools/school_master/edit_school_detials', 'Schools\School_Master::edit_school_detials');
$routes->match(['get', 'post'], 'schools/school_master/update_school_detials', 'Schools\School_Master::update_school_detials');
$routes->match(['get', 'post'], 'schools/special_order_entry', 'Schools\Special_Order_Entry::index');

// ------------------------------------------------------------------
// PHASE 166 - Special Order active POST routes
// Restores ONLY the five verified active Special-Order POST endpoints
// (Phase 165). All methods inherit Special_Order_Entry::__construct()
// -> is_user_logged(true); save/edit/update/delete gate permission 20;
// get_school_details is read-only (login-gated). Do NOT add GET to
// these. Do NOT route finalize_data (no such method in this controller).
// ------------------------------------------------------------------
$routes->post('schools/special_order_entry/get_school_details', 'Schools\Special_Order_Entry::get_school_details');
$routes->post('schools/special_order_entry/save_participant', 'Schools\Special_Order_Entry::save_participant');
$routes->post('schools/special_order_entry/edit_participant_details', 'Schools\Special_Order_Entry::edit_participant_details');
$routes->post('schools/special_order_entry/delete_participant_details', 'Schools\Special_Order_Entry::delete_participant_details');
$routes->post('schools/special_order_entry/update_participant_details', 'Schools\Special_Order_Entry::update_participant_details');

// User administration
$routes->match(['GET', 'POST'], 'user/admin_users', 'User\Admin_Users::index');
$routes->match(['GET', 'POST'], 'user/user_registration', 'User\User_Registration::index');
$routes->match(['GET', 'POST'], 'user/user_registration/add_user', 'User\User_Registration::add_user');
$routes->match(['GET', 'POST'], 'user/user_registration/cluster', 'User\User_Registration::cluster');
$routes->match(['GET', 'POST'], 'user/user_registration/add_cluster', 'User\User_Registration::add_cluster');
$routes->post('user/user_registration/userinsert', 'User\User_Registration::userinsert');
$routes->post('user/user_registration/edit_user_detials', 'User\User_Registration::edit_user_detials');
$routes->post('user/user_registration/update_user_detials', 'User\User_Registration::update_user_detials');
$routes->post('user/user_registration/delete_user_detials', 'User\User_Registration::delete_user_detials');
$routes->post('user/user_registration/clusterinsert', 'User\User_Registration::clusterinsert');
$routes->post('user/user_registration/edit_cluster_details', 'User\User_Registration::edit_cluster_details');
$routes->post('user/user_registration/update_cluster_details', 'User\User_Registration::update_cluster_details');
$routes->post('user/user_registration/delete_cluster_details', 'User\User_Registration::delete_cluster_details');
$routes->match(['GET', 'POST'], 'user/user_cluster', 'User\User_Cluster::index');
$routes->match(['GET', 'POST'], 'user/user_cluster/add_form', 'User\User_Cluster::add_form');
$routes->post('user/user_cluster/save_user_cluster', 'User\User_Cluster::save_user_cluster');
$routes->match(['GET', 'POST'], 'user/user_cluster/edit_user_cluster', 'User\User_Cluster::edit_user_cluster');
$routes->post('user/user_cluster/update_user_cluster', 'User\User_Cluster::update_user_cluster');
$routes->post('user/user_cluster/delete_user_cluster', 'User\User_Cluster::delete_user_cluster');

// Stage / allotment
$routes->get('stage/stage_details', 'Stage\Stage_Details::index');

// ------------------------------------------------------------------
// PHASE 145 - Stage Details mutation routes (POST only)
// Restores the Add/Edit/Update/Delete stage workflows. CI3 auto-routing
// previously resolved these; CI4 auto-routing is OFF so the four methods
// had become unreachable (404). All methods enforce login + permission 19
// in Stage_Details itself; mutation methods are safe to expose POST-only.
// Delete is kept separate and guarded. Do NOT add GET to these.
// ------------------------------------------------------------------
$routes->post('stage/stage_details/add_stage', 'Stage\Stage_Details::add_stage');
$routes->post('stage/stage_details/edit_stage_detials', 'Stage\Stage_Details::edit_stage_detials');
$routes->post('stage/stage_details/update_stage_detials', 'Stage\Stage_Details::update_stage_detials');
$routes->post('stage/stage_details/delete_stage_detials', 'Stage\Stage_Details::delete_stage_detials');

$routes->get('stage/allotment', 'Stage\Allotment::index');
$routes->match(['get', 'post'], 'stage/item_participant/participant_nodetails', 'Stage\Item_Participant::participant_nodetails');
$routes->post('stage/item_participant/stage_allot_fest_all', 'Stage\Item_Participant::stage_allot_fest_all');
$routes->match(['get', 'post'], 'stage/festival_scheduling', 'Stage\Festival_Scheduling::index');
$routes->match(['get', 'post'], 'stage/festival_scheduling/order_of_events', 'Stage\Festival_Scheduling::order_of_events');
$routes->match(['get', 'post'], 'stage/festival_scheduling/generate_schedule', 'Stage\Festival_Scheduling::generate_schedule');
$routes->match(['get', 'post'], 'stage/festival_scheduling/view_schedule', 'Stage\Festival_Scheduling::view_schedule');
$routes->match(['get', 'post'], 'stage/festival_scheduling/analyze_clashes', 'Stage\Festival_Scheduling::analyze_clashes');
$routes->match(['get', 'post'], 'stage/festival_scheduling/schedule_statistics', 'Stage\Festival_Scheduling::schedule_statistics');
$routes->match(['get', 'post'], 'stage/festival_scheduling/export_schedule', 'Stage\Festival_Scheduling::export_schedule');
$routes->get('stage/festival_scheduling/order_of_events/download', 'Stage\Festival_Scheduling::download');
$routes->get('stage/festival_scheduling/download', 'Stage\Festival_Scheduling::download');
$routes->match(['GET', 'POST'], 'report/prereport/stageallot_duration', 'Report\Prereport::stageallot_duration');
$routes->match(['GET', 'POST'], 'report/prereport/callsheet_first', 'Report\Prereport::callsheet_first');
$routes->match(['GET', 'POST'], 'report/prereport/callsheet_all', 'Report\Prereport::callsheet_all');
$routes->match(['GET', 'POST'], 'report/prereport/timesheetinterface', 'Report\Prereport::timesheetinterface');
$routes->match(['GET', 'POST'], 'report/prereport/score_sheet_interfaces', 'Report\Prereport::score_sheet_interfaces');
$routes->match(['GET', 'POST'], 'report/prereport/tabulation_report_interface', 'Report\Prereport::tabulation_report_interface');
$routes->match(['GET', 'POST'], 'report/prereport/four_reports', 'Report\Prereport::four_reports');

// Pre-report PDFs
$routes->post('report/prereportpdf/stageallot_duration', 'Report\Prereportpdf::stageallot_duration');
$routes->match(['GET', 'POST'], 'report/prereportpdf/callsheet_report', 'Report\Prereportpdf::callsheet_report');
$routes->match(['GET', 'POST'], 'report/prereportpdf/callsheet_all', 'Report\Prereportpdf::callsheet_all');
$routes->match(['GET', 'POST'], 'report/prereportpdf/call_date_stage', 'Report\Prereportpdf::call_date_stage');

// Ajax2 endpoints
$routes->match(['GET', 'POST'], 'ajax/ajax2/fetch_callsheet_festival', 'Ajax\Ajax2::fetch_callsheet_festival');
$routes->match(['GET', 'POST'], 'ajax/ajax2/fetch_school_from_festival', 'Ajax\Ajax2::fetch_school_from_festival');
$routes->match(['GET', 'POST'], 'ajax/ajax2/fetch_item_name', 'Ajax\Ajax2::fetch_item_name');

// Result entry / publishing (primary landing pages only)
$routes->get('result/resultentry', 'Result\Resultentry::index');
$routes->get('result/resultentry/item_result_list', 'Result\Resultentry::item_result_list');
$routes->get('publishresult/resultindex/resultview', 'Publishresult\Resultindex::resultview');

// ------------------------------------------------------------------
// PHASE 97 - Protected Admin Users AJAX endpoints (POST only)
// Required by js/user/adminusers.js loadSubDistrict()/loadSchool().
// Loadajax constructor enforces login + USER_GROUP == 'W'.
// Do NOT add GET or wildcard routes here.
// ------------------------------------------------------------------
$routes->post('ajax/loadajax/get_subdistrict_details', 'Ajax\Loadajax::get_subdistrict_details');
$routes->post('ajax/loadajax/get_school_details', 'Ajax\Loadajax::get_school_details');
$routes->post('ajax/loadajax/get_edu_district_details', 'Ajax\Loadajax::get_edu_district_details');
$routes->post('ajax/loadajax/get_subdistrict_details_of_edu_district', 'Ajax\Loadajax::get_subdistrict_details_of_edu_district');
$routes->post('ajax/loadajax/get_subdistrict_details_small', 'Ajax\Loadajax::get_subdistrict_details_small');
$routes->post('ajax/loadajax/change_confirmation_status', 'Ajax\Loadajax::change_confirmation_status');
$routes->post('ajax/change_confirmation_status', 'Ajax\Loadajax::change_confirmation_status');

// ------------------------------------------------------------------
// PHASE 101 - Stage Allotment item-details AJAX endpoint (POST only)
// Used by js/stages.js fetch_item_details() after item code entry.
// Allotment constructor enforces login + permission; method is SELECT-only.
// Do NOT add GET or wildcard routes here.
// ------------------------------------------------------------------
$routes->post('stage/allotment/get_item_details', 'Stage\Allotment::get_item_details');

// ------------------------------------------------------------------
// Backup Database as SQL (Import controller)
// Reachable via menu_left "Backup Database as SQL". The controller keeps
// the backup files listing and triggers the .sql download via ?do=backup.
// ------------------------------------------------------------------
$routes->get('import/backup_data_sql', 'Import::backup_data_sql');


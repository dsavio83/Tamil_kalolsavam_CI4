<?php

namespace App\Models\Login;


class Login_Model extends \App\Models\BaseModel {

    function __construct () {
        parent::__construct ();
    }

    function logincheck($userName, $password) {
        $logdata['ip'] = service('request')->getIPAddress();
        $logdata['user_name'] = $userName;
        $this->db->where('user_name', $userName);
        $user_master = $this->db->get('user_master');
        
        $username_exists = false;
        if ($user_master->getNumRows() > 0) {
            $username_exists = true;
            $user = $user_master->getResultArray();
            $logdata['user_id'] = $user[0]['user_id'];
            $logdata['rev_district_code'] = $user[0]['rev_district_code'];
            $logdata['sub_district_code'] = $user[0]['sub_district_code'];
            $logdata['school_code'] = $user[0]['school_code'];
        }

        if (!$username_exists) {
            $logdata['status'] = 'F';
            $this->db->insert('z_login_log', $logdata);
            return 2; // Username not found
        }

        $this->db->where('user_name', $userName);
        $this->db->where('password', get_encr_password($password));
        $result = $this->db->get('user_master');

        if ($result->getNumRows() > 0) {
            $logdata['status'] = 'L';
        } else {
            $logdata['status'] = 'F';
            $this->db->insert('z_login_log', $logdata);
            return 3; // Password does not match
        }
        $this->db->insert('z_login_log', $logdata);

        return $result->getResultArray();
    }

    function give_user_details() {
        $USERID = $this->session->get('USERID');
        $this->result = array();
        $this->db->where('UM.user_id', $USERID);
        $this->db->from('user_master AS UM');
        $this->db->select('UM.*, user_id, user_name,password,is_change_password,created_by');
        $result = $this->db->get();
        return $result->getResultArray();
    }

    function check_pwd_details() {
        $USERID = $this->session->get('USERID');

        $this->result = array();
        $this->db->where('UM.user_id', $USERID);
        $this->db->from('user_master AS UM');
        $this->db->select('UM.*, user_id, user_name,password,is_change_password,created_by');
        $result = $this->db->get();
        return $result->getResultArray();
    }

    function checkexistpwd($pwd) {
        $USRID = $this->session->get('USERID');
        $this->db->where('user_id', $USRID);
        $this->db->where('password', get_encr_password($pwd));
        $result = $this->db->get('user_master');
        return $result->getResultArray();
    }

    function save_chgpwd_details() {
        $this->db->transStart();

        $USRID = $this->session->get('USERID');

        // PHASE 188: Removed destructive bulk DELETE from user_master.
        // The legacy code conditionally deleted every non-W user whose
        // sub_district_code differed from the session user's own, during a
        // routine password change. That was a P0 data-loss defect. Only the
        // session user's password/profile UPDATE (below) is retained; no
        // other user's record is touched.

        $request = service('request');
        $data['password'] = get_encr_password($request->getPost('txtNewPassword'));
        $data['is_change_password'] = "Y";
        $data['name'] = $request->getPost('Name');
        $mobile = $request->getPost('Mobile_Number');
        $data['mobile'] = (!empty($mobile)) ? $mobile : null;
        $data['email'] = $request->getPost('Email_id');
        $this->db->where('user_id', $USRID);
        $this->db->update('user_master', $data);

        $this->session->set(array('CHANGEPWD' => 'Y'));

        $this->db->where('user_id', $USRID);
        $user_master = $this->db->get('user_master');

        if ($user_master->getNumRows() > 0) {
            $user = $user_master->getResultArray();
            $logdata['user_id'] = $user[0]['user_id'];
            $logdata['rev_district_code'] = $user[0]['rev_district_code'];
            $logdata['sub_district_code'] = $user[0]['sub_district_code'];
            $logdata['school_code'] = $user[0]['school_code'];
            $logdata['ip'] = service('request')->getIPAddress();
            $logdata['user_name'] = $user[0]['user_name'];
            $logdata['status'] = 'C';
            $this->db->insert('z_login_log', $logdata);
        }


        $this->db->transComplete();
    }

    function logout_user() {
        $keys = [
            'USERID',
            'USERID_LIVE',
            'USER_NAME',
            'CHANGEPWD',
            'USER_GROUP',
            'DISTRICT',
            'SUB_DISTRICT',
            'SCHOOL_CODE',
            'EDU_DISTRICT',
            'USER_TYPE',
            'REQUEST_URI'
        ];
        $this->session->remove($keys);
        if (session_status() === PHP_SESSION_ACTIVE) {
            session()->destroy();
        }
    }

    function get_cluster_details($subdist) {
        //$user_id		=	$this->session->get('USERID');
        //$subdist		=	$this->input->post('sel_sub_district_id');
        if (empty($subdist))
            $subdist = $this->session->get('SUB_DISTRICT');

        $this->db->select('UM.user_id, UM.user_name,
		COUNT(UC.school_code) AS total, COUNT(SD.school_code) AS data_entered, COUNT(SF.is_finalize) AS finialized');
        $this->db->from('user_cluster AS UC');
        $this->db->join('user_master AS UM', 'UM.user_id = UC.user_id');
        $this->db->join('school_details AS SD', 'SD.school_code = UC.school_code', 'LEFT');
        $this->db->join('school_details AS SF', "SF.school_code = UC.school_code AND SF.is_finalize = 'Y'", 'LEFT');
        //$this->db->where('UM.user_id',$user_id);
        $this->db->where('UM.sub_district_code', $subdist);
        $this->db->orderBy('data_entered');
        $this->db->groupBy('UM.user_id');
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function get_unclustersch_details($subdist) {
        $user_id = $this->session->get('USERID');
        if (empty($subdist))
            $subdist = $this->session->get('SUB_DISTRICT');
        $this->db->select('count( m.school_code ) AS mcode');
        $this->db->from('school_master AS m');
        $this->db->where('m.sub_district_code', $subdist);
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function get_unclustersch_finentry($subdist) {
        $this->db->select('count( m.school_code ) AS ent, count( m2.school_code ) AS fin');
        $this->db->from('school_details m');
        $this->db->join('school_master AS w', "w.school_code = m.school_code AND w.sub_district_code ='$subdist'");
        $this->db->join('school_details AS m2', "m.school_code = m2.school_code AND m2.is_finalize = 'Y'", 'LEFT');
        $this->db->where("m.school_code NOT IN (SELECT c.school_code FROM user_cluster c JOIN school_master t ON c.school_code = t.school_code AND t.sub_district_code ='$subdist')");
        $ret = $this->db->get();
        return $ret->getResultArray();
        /*
          $qrt="SELECT count( m.school_code ) AS ent, count( m2.school_code ) AS fin
          FROM school_details m
          JOIN school_master w ON w.school_code = m.school_code
          AND w.sub_district_code ='$subdist'
          LEFT JOIN school_details AS m2 ON m.school_code = m2.school_code
          AND m2.is_finalize = 'Y'
          WHERE m.school_code NOT
          IN (

          SELECT c.school_code
          FROM user_cluster c
          JOIN school_master t ON c.school_code = t.school_code
          AND t.sub_district_code ='$subdist'
          ) ";
          $fest_detail1		=	$this->db->query($qrt);
          return $fest_detail1->getResultArray();
         */
    }

    function get_sub_school_details($subdist = '') {
        $user_id = $this->session->get('USERID');
        //$subdist		=	$this->input->post('sel_sub_district_id');
        if (empty($subdist))
            $subdist = $this->session->get('SUB_DISTRICT');

        $this->db->where('sub_district_code', $subdist);
        $total_school = $this->db->countAllResults('school_master');

        $this->db->where('sub_district_code', $subdist);
        $cluster_school = $this->db->countAllResults('user_cluster');

        $this->db->where('SM.sub_district_code', $subdist);
        $this->db->join('school_details AS SD', 'SM.school_code = SD.school_code');
        $data_entered = $this->db->countAllResults('school_master AS SM');

        $this->db->where('SM.sub_district_code', $subdist);
        $this->db->where('SD.is_finalize', 'Y');
        $this->db->join('school_details AS SD', 'SM.school_code = SD.school_code');
        $confirmed = $this->db->countAllResults('school_master AS SM');


        $this->db->select('confirm_data_entry');
        $this->db->where('sub_district_code', $subdist);
        $confirm_data_entry = $this->db->get('sub_district_master');
        $confirm_data_entry = $confirm_data_entry->getResultArray();


        $return_array['total_school'] = $total_school;
        $return_array['cluster_school'] = $cluster_school;
        $return_array['data_entered'] = $data_entered;
        $return_array['confirmed'] = $confirmed;
        $return_array['confirm_data_entry'] = $confirm_data_entry[0]['confirm_data_entry'] ?? 'N';

        return $return_array;
    }

    function schooldetails($userId = '') {

        $user_id = $userId ? $userId : $this->session->get('USERID');
        $subdist = $this->session->get('SUB_DISTRICT');
        $usrtype = $this->session->get('USER_TYPE');
        if (3 > $usrtype) {
            $user_id = $this->input->post('hidClusterId');
            $this->db->select('sub_district_code');
            $this->db->where('user_id', $user_id);
            $this->db->groupBy('user_id, sub_district_code');
            $result = $this->db->get('user_cluster');
            $result = $result->getResultArray();
            $subdist = $result[0]['sub_district_code'] ?? $subdist;
        }

        $this->db->select('sd.school_code, sd.sub_district_code, sm.school_name,dt.is_finalize');
        $this->db->from('user_cluster AS sd');
        $this->db->join('school_master AS sm', 'sm.school_code = sd.school_code');
        $this->db->join('school_details AS dt', 'dt.school_code=sd.school_code', 'LEFT');
        $this->db->where('sd.user_id', $user_id);
        $this->db->where('sd.sub_district_code', $subdist);
        $this->db->orderBy('sd.school_code');
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function clusterdetails($userId = '') {

        $user_id = $userId ? $userId : $this->session->get('USERID');
        $usrtype = $this->session->get('USER_TYPE');
        if (3 > $usrtype) {
            $user_id = $this->input->post('hidClusterId');
        }
        $this->db->select('user_name, name, mobile, email');
        $this->db->where('user_id', $user_id);
        $user_details = $this->db->get('user_master');
        return $user_details->getResultArray();
    }

    function schoolpartcip() {
        $this->db->select('sd.school_code');
        $this->db->from('school_details AS sd');
        $this->db->orderBy('sd.school_code');
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function get_confirmation_status($school_code) {
        $this->db->select('is_finalize');
        $this->db->where('school_code', $school_code);
        $this->db->from('school_details');
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function set_confirmation_status($school_code, $status) {
        // Start database transaction
        $this->db->transStart();

        try {
            // Update school_details table
            $this->db->where('school_code', $school_code);
            $details_updated = $this->db->update('school_details', array('is_finalize' => $status));

            // Check if update was successful (even if no rows were affected, it might be because it's already at the target value)
            if (!$details_updated) {
                $this->db->transRollback();
                return 'ERROR: School details update failed. Last query: ' . $this->db->last_query();
            }

            // Verify the field was actually set to the correct value
            $this->db->where('school_code', $school_code);
            $verify_details = $this->db->get('school_details');
            if ($verify_details->getNumRows() > 0) {
                $current_value = $verify_details->getRowArray()['is_finalize'];
                if ($current_value !== $status) {
                    $this->db->transRollback();
                    return 'ERROR: School details verification failed. Expected: ' . $status . ', Got: ' . $current_value;
                }
            }

            // Update school_master table
            $this->db->where('school_code', $school_code);
            $master_updated = $this->db->update('school_master', array('master_confirm' => $status));

            // Check if update was successful (even if no rows were affected, it might be because it's already at the target value)
            if (!$master_updated) {
                $this->db->transRollback();
                return 'ERROR: School master update failed. Last query: ' . $this->db->last_query();
            }

            // Verify the field was actually set to the correct value
            $this->db->where('school_code', $school_code);
            $verify_master = $this->db->get('school_master');
            if ($verify_master->getNumRows() > 0) {
                $current_value = $verify_master->getRowArray()['master_confirm'];
                if ($current_value !== $status) {
                    $this->db->transRollback();
                    return 'ERROR: School master verification failed. Expected: ' . $status . ', Got: ' . $current_value;
                }
            }

            // Insert log entry
            $data = array();
            $data['school_code'] = $school_code;
            $data['status'] = $status;
            $data['ip'] = $this->input->ip_address();
            $data['user_id'] = $this->session->get('USERID');

            $log_inserted = $this->db->insert('z_school_confirm_log', $data);
            if (!$log_inserted) {
                $this->db->transRollback();
                return 'ERROR: Log insertion failed. Last query: ' . $this->db->last_query();
            }

            // Complete transaction
            $this->db->transComplete();

            if ($this->db->trans_status() === FALSE) {
                return 'ERROR: Transaction failed. Transaction status: ' . $this->db->trans_status();
            }

            // Return appropriate status
            if ($status == 'N') {
                return 'No';
            }
            else if ($status == 'Y') {
                return 'Yes';
            }

            return 'ERROR: Unexpected status value: ' . $status;

        } catch (Exception $e) {
            $this->db->transRollback();
            return 'ERROR: Exception occurred: ' . $e->getMessage();
        }
    }

    function get_district_school_details($dist) {
        $this->db->where('rev_district_code', $dist);
        $total_school = $this->db->countAllResults('school_master');

        $this->db->where('sub_district_code IN (SELECT sub_district_code FROM sub_district_master WHERE rev_district_code= ' . $dist . ')', NULL, FALSE);
        $cluster_school = $this->db->countAllResults('user_cluster');

        $this->db->where('SM.sub_district_code IN (SELECT SDM.sub_district_code FROM sub_district_master SDM WHERE SDM.rev_district_code= ' . $dist . ')', NULL, FALSE);
        $this->db->join('school_details AS SD', 'SM.school_code = SD.school_code');
        $data_entered = $this->db->countAllResults('school_master AS SM');

        $this->db->where('SM.sub_district_code IN (SELECT SDM.sub_district_code FROM sub_district_master SDM WHERE SDM.rev_district_code= ' . $dist . ')', NULL, FALSE);
        $this->db->where('SD.is_finalize', 'Y');
        $this->db->join('school_details AS SD', 'SM.school_code = SD.school_code');
        $confirmed = $this->db->countAllResults('school_master AS SM');

        $return_array['total_school'] = $total_school;
        $return_array['cluster_school'] = $cluster_school;
        $return_array['data_entered'] = $data_entered;
        $return_array['confirmed'] = $confirmed;

        return $return_array;
    }

    function nonclustdetails_sname($subdist) {
        if (empty($subdist))
            $subdist = $this->session->get('SUB_DISTRICT');
        $this->db->select('m.school_code, m2.school_name,m.is_finalize');
        $this->db->from('school_details m');
        $this->db->join('school_master AS m2', "m.school_code = m2.school_code AND m2.sub_district_code ='$subdist'");
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function nonclustdetails_nosname($subdist) {
        if (empty($subdist))
            $subdist = $this->session->get('SUB_DISTRICT');
        $this->db->select('m2.school_name, m2.school_code');
        $this->db->from('school_master AS m2');
        $this->db->where('m2.sub_district_code', $subdist);
        $school_details = $this->db->get();
        return $school_details->getResultArray();
    }

    function get_sub_admin_details($sub_district_code) {
        $this->db->where('sub_district_code', $sub_district_code);
        $this->db->where('user_group', 'A');
        $user_master = $this->db->get('user_master');
        return $user_master->getResultArray();
    }

    function get_subdist_district_code($sub_district_code) {
        $this->db->select('rev_district_code');
        $this->db->where('sub_district_code', $sub_district_code);
        $result = $this->db->get('sub_district_master');
        $row = $result->getRowArray();
        return ($row && isset($row['rev_district_code'])) ? $row['rev_district_code'] : $this->session->get('DISTRICT');
    }

    function changeKalolsavam($subdist, $sub_dist_name) {

        $data['sub_dist_kalolsavam_name'] = $sub_dist_name . '  Subdistrict Kalolsavam 2022 - 2024 ';
        $this->db->where('sub_district_code', $subdist);
        if ($this->db->update('sub_dist_kalolsavam_master', $data))
            return true;
        else
            return false;
    }

}

?>
